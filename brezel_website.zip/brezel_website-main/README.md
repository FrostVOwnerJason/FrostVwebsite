# brezel_website
A small clean website for your FiveM server
support at discord.gg/brezelservices
fully responsive
This website was written by Yoshi™#1234, feel free to skid it. thats what you do anyways 
